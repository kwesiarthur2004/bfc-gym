# 🚀 Quick Start Guide

## One Server, One URL - Everything in One Place!

The backend now serves the frontend files, so you only need to start **ONE server**.

---

## Step 1: Start the Server

1. **Open a terminal/command prompt**

2. **Navigate to the Backend folder:**
   ```bash
   cd C:\Users\User\Documents\BFCGYM\Backend
   ```

3. **Start the server:**
   ```bash
   npm start
   ```

4. **You should see:**
   ```
   ==================================================
   Body Fitness Center - Server Started
   ==================================================
   Server running on port 3000
   Frontend: http://localhost:3000/login.html
   Open in browser: http://localhost:3000
   ==================================================
   ```

---

## Step 2: Open in Browser

**Simply open your browser and go to:**
```
http://localhost:3000
```

OR

```
http://localhost:3000/login.html
```

**That's it!** Everything is served from the same server - no CORS issues, no separate frontend server needed.

---

## Step 3: Login

- **Username:** `admin`
- **Password:** `admin123`

Click "Login" and you'll be redirected to the dashboard.

---

## Available Pages

All pages are accessible from the same server:

- **Login:** `http://localhost:3000/` or `http://localhost:3000/login.html`
- **Dashboard:** `http://localhost:3000/dashboard.html`
- **Check-In:** `http://localhost:3000/checkin.html`
- **Attendance:** `http://localhost:3000/attendance.html`
- **Reports:** `http://localhost:3000/Reports.html`

---

## What Changed?

✅ **Before:** Needed 2 servers (backend on 3000, frontend on 5500)  
✅ **Now:** Only 1 server (everything on 3000)

✅ **Before:** CORS issues if opening HTML files directly  
✅ **Now:** No CORS issues - everything served from same origin

✅ **Before:** Complex setup with multiple terminals  
✅ **Now:** Just `npm start` and open browser!

---

## Troubleshooting

### Port 3000 already in use?
```bash
# Find the process
netstat -ano | findstr :3000

# Kill it (replace <PID> with the number)
taskkill /PID <PID> /F

# Then start again
npm start
```

### Can't connect?
- Make sure the server is running (you should see the startup message)
- Check that you're using `http://localhost:3000` (not `file://`)
- Try refreshing the browser page

---

**That's it! Much simpler now! 🎉**
