# How to Serve the Login Page from HTTP (Not file://)

## ✅ Option 1: Use the Backend Server (EASIEST - Already Set Up!)

The backend server already serves all frontend files. Just start it:

### Steps:

1. **Open PowerShell or Command Prompt**

2. **Navigate to the Backend folder:**
   ```powershell
   cd C:\Users\User\Documents\BFCGYM\Backend
   ```

3. **Start the server:**
   ```powershell
   npm start
   ```

4. **Open your browser and go to:**
   ```
   http://localhost:3000
   ```
   OR
   ```
   http://localhost:3000/login.html
   ```

**That's it!** The login page will be served from `http://localhost:3000` (not `file://`).

---

## 🔧 Option 2: Use Port 5500 (If You Prefer)

If you specifically want to use port 5500, you have several options:

### Method A: Python HTTP Server (If Python is installed)

1. **Open PowerShell or Command Prompt**

2. **Navigate to the frontend folder:**
   ```powershell
   cd C:\Users\User\Documents\BFCGYM\frontend
   ```

3. **Start Python HTTP server on port 5500:**
   ```powershell
   python -m http.server 5500
   ```
   OR if you have Python 2:
   ```powershell
   python -m SimpleHTTPServer 5500
   ```

4. **Open your browser and go to:**
   ```
   http://localhost:5500/login.html
   ```

5. **⚠️ IMPORTANT:** You'll also need to start the backend server separately:
   - Open another terminal
   - Navigate to `Backend` folder
   - Run `npm start`
   - Backend will run on port 3000

---

### Method B: Node.js http-server (If you have Node.js)

1. **Install http-server globally (one-time):**
   ```powershell
   npm install -g http-server
   ```

2. **Navigate to the frontend folder:**
   ```powershell
   cd C:\Users\User\Documents\BFCGYM\frontend
   ```

3. **Start http-server on port 5500:**
   ```powershell
   http-server -p 5500
   ```

4. **Open your browser and go to:**
   ```
   http://localhost:5500/login.html
   ```

5. **⚠️ IMPORTANT:** You'll also need to start the backend server separately:
   - Open another terminal
   - Navigate to `Backend` folder
   - Run `npm start`
   - Backend will run on port 3000

---

### Method C: VS Code Live Server Extension

1. **Install Live Server extension in VS Code:**
   - Open VS Code
   - Go to Extensions (Ctrl+Shift+X)
   - Search for "Live Server"
   - Install it

2. **Open the frontend folder in VS Code**

3. **Right-click on `login.html`**
   - Select "Open with Live Server"
   - It will open on a random port (usually 5500 or 5501)

4. **⚠️ IMPORTANT:** You'll also need to start the backend server separately:
   - Open a terminal in VS Code
   - Navigate to `Backend` folder
   - Run `npm start`
   - Backend will run on port 3000

---

## ⚠️ Important Notes:

### If Using Option 2 (Port 5500):

- **You need TWO servers running:**
  1. Frontend server on port 5500 (serves HTML/CSS/JS)
  2. Backend server on port 3000 (serves API)

- **CORS Configuration:**
  - The backend is already configured to accept requests from `http://localhost:5500`
  - If you use a different port, you may need to update `Backend/server.js` CORS settings

### If Using Option 1 (Port 3000):

- **You only need ONE server:**
  - Backend serves both API and frontend files
  - No CORS issues
  - Simpler setup

---

## 🎯 Recommended Approach:

**Use Option 1** - It's the simplest and already configured!

Just run:
```powershell
cd Backend
npm start
```

Then open: `http://localhost:3000`

---

## 🔍 How to Check if Server is Running:

- **Backend (port 3000):** Open `http://localhost:3000/health` in browser
- **Frontend (port 5500):** Open `http://localhost:5500/login.html` in browser

---

## 🐛 Troubleshooting:

### "Cannot GET /" or 404 errors:
- Make sure you're using `http://localhost:PORT` (not `file://`)
- Check that the server is actually running
- Verify you're in the correct directory

### CORS errors:
- Make sure both frontend and backend servers are running
- Check that the frontend URL matches the CORS origin in `Backend/server.js`

### Port already in use:
```powershell
# Find what's using the port
netstat -ano | findstr :5500

# Kill the process (replace <PID> with the number)
taskkill /PID <PID> /F
```
