# Invitation Codes - Staff Access Only

## Access Restricted To

This system is **only accessible to**:
- **Receptionists** - Front desk staff
- **Trainers** - Gym trainers
- **Managers** - Management staff

---

## Available Invitation Codes

### Receptionist Codes

1. **RECEPTION-2024**
   - Role: Receptionist
   - Status: Active
   - Max Uses: 20
   - Used: 5
   - Remaining: 15
   - Expires: 2025-12-31

2. **RECEPTION-001**
   - Role: Receptionist
   - Status: Active
   - Max Uses: 5
   - Used: 1
   - Remaining: 4
   - Expires: 2025-12-31

---

### Trainer Codes

1. **TRAINER-2024**
   - Role: Trainer
   - Status: Active
   - Max Uses: 15
   - Used: 3
   - Remaining: 12
   - Expires: 2025-12-31

2. **TRAINER-001**
   - Role: Trainer
   - Status: Active
   - Max Uses: 5
   - Used: 0
   - Remaining: 5
   - Expires: 2025-12-31

---

### Manager Codes

1. **MANAGER-2024**
   - Role: Manager
   - Status: Active
   - Max Uses: 10
   - Used: 2
   - Remaining: 8
   - Expires: 2025-12-31

2. **MANAGER-001**
   - Role: Manager
   - Status: Active
   - Max Uses: 3
   - Used: 0
   - Remaining: 3
   - Expires: 2025-12-31

---

## Pre-Created Staff Accounts

### Manager Account
- **Invitation Code:** `MANAGER-2024`
- **Username:** `manager1`
- **Password:** `manager123`
- **Name:** John Manager

### Receptionist Account
- **Invitation Code:** `RECEPTION-2024`
- **Username:** `reception1`
- **Password:** `reception123`
- **Name:** Sarah Receptionist

### Trainer Account
- **Invitation Code:** `TRAINER-2024`
- **Username:** `trainer1`
- **Password:** `trainer123`
- **Name:** Mike Trainer

---

## How to Use

### For Existing Staff (Login)
1. Enter your **Invitation Code** (must match your role)
2. Enter your **Username**
3. Enter your **Password**
4. Click "Login"

### For New Staff (Registration)
1. Click "Don't have an account? Register"
2. Enter a valid **Invitation Code** (role will be assigned automatically)
3. Choose a **Username**
4. Choose a **Password**
5. Enter your **Name** (optional, defaults to username)
6. Click "Register"

**Note:** Your role (receptionist, trainer, or manager) will be automatically assigned based on the invitation code you use.

---

## Role-Based Access

All staff members (receptionists, trainers, and managers) have access to:
- Dashboard
- Member Management
- Check-In System
- Attendance Tracking
- Reports

**Access is restricted to these three roles only.** Other roles or unauthorized users will be denied access.

---

## Important Notes

- Invitation codes are **case-sensitive**
- Each code can only be used a limited number of times
- Codes have expiration dates
- Users must use the same invitation code they registered with to login
- Role is automatically assigned based on invitation code
- Only receptionists, trainers, and managers can access the system

---

## Security

- All invitation codes are role-specific
- System validates role on every request
- Unauthorized roles are automatically denied access
- Session-based authentication ensures secure access
