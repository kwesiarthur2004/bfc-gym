// Body Fitness Center - Frontend JavaScript
// Invitation-based access system

// Use relative URLs if served from same server, or absolute URL if served separately
// If frontend is on port 5500 and backend on 3000, use: 'http://localhost:3000'
// If served from same server (port 3000), use: ''
// Backend typically runs on port 3000, frontend dev server on port 5500
const API_BASE_URL = window.location.port === '5500' ? 'http://localhost:3000' : '';

// Session-based authentication - no token storage needed
// Sessions are managed server-side via cookies

function clearAuthToken() {
    // No token to clear with session-based auth
    // Session is cleared server-side on logout
}

async function checkAuthentication() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/auth/me`, {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            window.location.href = 'login.html';
            return false;
        }
        return true;
    } catch (error) {
        window.location.href = 'login.html';
        return false;
    }
}

/**
 * ============================================
 * LOGIN PAGE FUNCTIONALITY
 * ============================================
 */

/**
 * Initializes login page functionality when DOM is loaded
 * Handles form submission, validation, and API communication
 */
function initializeLoginPage() {
    const loginForm = document.getElementById('login-form');
    if (!loginForm) return;

    // Get form elements
    const errorMessage = document.getElementById('error-message');
    const invitationCodeInput = document.getElementById('invitation-code');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const rememberMeCheckbox = document.getElementById('remember-me');
    const registerLink = document.getElementById('register-link');

    /**
     * Displays error message to the user
     * @param {string} message - The error message to display
     */
    function showError(message) {
        if (errorMessage) {
            errorMessage.textContent = message;
            errorMessage.classList.add('show');
        }
    }

    /**
     * Hides the error message
     */
    function hideError() {
        if (errorMessage) {
            errorMessage.classList.remove('show');
            errorMessage.textContent = '';
        }
    }

    /**
     * Handles login form submission
     * Validates input, sends data to backend API, and redirects on success
     */
    loginForm.addEventListener('submit', async function(e) {
        // Prevent default form submission behavior
        e.preventDefault();
        hideError();

        // Get form values and trim whitespace
        const invitationCode = invitationCodeInput ? invitationCodeInput.value.trim() : '';
        const username = usernameInput.value.trim();
        const password = passwordInput.value;
        const rememberMe = rememberMeCheckbox ? rememberMeCheckbox.checked : false;

        // Validate that all required fields are filled
        if (!invitationCode || !username || !password) {
            showError('Please enter invitation code, username, and password');
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/api/auth/login`, {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    invitationCode: invitationCode,
                    username: username,
                    password: password,
                    rememberMe: rememberMe
                })
            });

            // Check if response is ok first
            if (!response.ok) {
                // Try to get error message from response
                let errorText = '';
                try {
                    errorText = await response.text();
                    const errorData = JSON.parse(errorText);
                    showError(errorData.message || `Server error (${response.status}): ${errorData.error || 'Unknown error'}`);
                } catch (e) {
                    showError(`Server error (${response.status}): ${errorText || response.statusText}`);
                }
                return;
            }

            // Parse JSON response
            let data;
            let text = '';
            try {
                text = await response.text();
                if (!text) {
                    showError('Server returned empty response. Make sure the backend server is running on port 3000.');
                    return;
                }
                data = JSON.parse(text);
            } catch (parseError) {
                console.error('JSON parse error:', parseError);
                console.error('Response text:', text);
                showError('Server returned invalid response. Make sure the backend server is running and accessible.');
                return;
            }

            if (data.success) {
                window.location.href = 'dashboard.html';
            } else {
                showError(data.message || 'Login failed. Please check your credentials.');
            }
        } catch (error) {
            console.error('Login error:', error);
            if (error.message.includes('Failed to fetch') || error.name === 'TypeError') {
                showError('Cannot connect to server. Make sure the backend server is running on port 3000.');
            } else {
                showError(error.message || 'An error occurred. Please try again later.');
            }
        }
    });

    // Clear error message when user starts typing
    if (invitationCodeInput) {
        invitationCodeInput.addEventListener('input', hideError);
    }
    if (usernameInput) {
        usernameInput.addEventListener('input', hideError);
    }
    if (passwordInput) {
        passwordInput.addEventListener('input', hideError);
    }

    // Handle register link click
    if (registerLink) {
        registerLink.addEventListener('click', function(e) {
            e.preventDefault();
            showRegisterForm();
        });
    }
}

// Show register form (simple toggle for now)
function showRegisterForm() {
    const loginForm = document.getElementById('login-form');
    const formTitle = document.querySelector('.form-title');
    const loginButton = loginForm.querySelector('button[type="submit"]');
    const registerLink = document.getElementById('register-link');
    
    if (!loginForm) return;

    // Change form to registration mode
    if (formTitle) formTitle.textContent = 'Create Account';
    if (loginButton) loginButton.textContent = 'Register';
    if (registerLink) registerLink.textContent = 'Already have an account? Login';
    
    // Update form submission handler
    loginForm.onsubmit = async function(e) {
        e.preventDefault();
        const errorMessage = document.getElementById('error-message');
        
        function showError(msg) {
            if (errorMessage) {
                errorMessage.textContent = msg;
                errorMessage.classList.add('show');
            }
        }
        
        const invitationCode = document.getElementById('invitation-code').value.trim();
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        const name = username; // Use username as name for simplicity

        if (!invitationCode || !username || !password) {
            showError('Please fill in all fields');
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/api/auth/register`, {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    invitationCode: invitationCode,
                    username: username,
                    password: password,
                    name: name
                })
            });

            const data = await response.json();

            if (response.ok && data.success) {
                window.location.href = 'dashboard.html';
            } else {
                showError(data.message || 'Registration failed');
            }
        } catch (error) {
            console.error('Registration error:', error);
            showError('An error occurred. Please try again later.');
        }
    };

    // Update register link to toggle back
    if (registerLink) {
        registerLink.onclick = function(e) {
            e.preventDefault();
            location.reload(); // Simple reload to reset form
        };
    }
}

/**
 * ============================================
 * DASHBOARD PAGE FUNCTIONALITY
 * ============================================
 */

/**
 * Loads dashboard statistics from the backend API
 * Updates the metrics cards with current data
 */
async function loadDashboardData() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/dashboard/stats`, {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (response.ok) {
            const data = await response.json();
            // Update UI with fetched data
            updateMetrics(data);
            updateRecentAttendance(data.recentAttendance || []);
            updateExpirations(data.expirations || []);
        } else {
            // Use default values if API fails (graceful degradation)
            console.log('Using default dashboard data');
        }
    } catch (error) {
        console.error('Error loading dashboard data:', error);
        // Use default values if API fails
    }
}

/**
 * Updates the metric cards on the dashboard with new data
 * @param {Object} data - Object containing metric values
 */
function updateMetrics(data) {
    if (data.totalMembers !== undefined) {
        const element = document.getElementById('total-members');
        if (element) element.textContent = data.totalMembers;
    }
    if (data.checkedInToday !== undefined) {
        const element = document.getElementById('checked-in-today');
        if (element) element.textContent = data.checkedInToday;
    }
    if (data.expiredMemberships !== undefined) {
        const element = document.getElementById('expired-memberships');
        if (element) element.textContent = data.expiredMemberships;
    }
    if (data.totalStaff !== undefined) {
        const element = document.getElementById('total-staff');
        if (element) element.textContent = data.totalStaff;
    }
}

/**
 * Updates the recent attendance table with new data
 * @param {Array} attendance - Array of attendance records
 */
function updateRecentAttendance(attendance) {
    const tbody = document.getElementById('recent-attendance-tbody');
    if (!tbody || !attendance.length) return;

    tbody.innerHTML = attendance.map(item => `
        <tr>
            <td>${item.id}</td>
            <td>${item.memberName}</td>
            <td>${item.checkInTime}</td>
            <td><span class="status-badge status-checked-in">Checked-in</span></td>
        </tr>
    `).join('');
}

/**
 * Updates the membership expirations table with new data
 * @param {Array} expirations - Array of expiration records
 */
function updateExpirations(expirations) {
    const tbody = document.getElementById('expirations-tbody');
    if (!tbody || !expirations.length) return;

    tbody.innerHTML = expirations.map(item => `
        <tr>
            <td>${item.id}</td>
            <td>${item.memberName}</td>
            <td>${item.expirationDate}</td>
        </tr>
    `).join('');
}

/**
 * Loads current user information from the API
 * Updates the welcome message with user's name
 */
async function loadUserInfo() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/auth/me`, {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (response.ok) {
            const data = await response.json();
            const welcomeMessage = document.getElementById('welcome-message');
            if (welcomeMessage && data.user && data.user.name) {
                const roleDisplay = data.user.role ? ` (${data.user.role.charAt(0).toUpperCase() + data.user.role.slice(1)})` : '';
                welcomeMessage.textContent = `Welcome back, ${data.user.name}${roleDisplay}`;
            }
        }
    } catch (error) {
        console.error('Error loading user info:', error);
    }
}

/**
 * Initializes dashboard page functionality
 * Checks authentication, loads data, and sets up logout
 */
async function initializeDashboardPage() {
    const dashboardMain = document.querySelector('.dashboard-main');
    if (!dashboardMain) return;

    if (!(await checkAuthentication())) {
        return;
    }

    loadDashboardData();
    loadUserInfo();

    const logoutLink = document.getElementById('logout-link');
    if (logoutLink) {
        logoutLink.addEventListener('click', async function(e) {
            e.preventDefault();
            try {
                await fetch(`${API_BASE_URL}/api/auth/logout`, {
                    method: 'POST',
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            } catch (error) {
                console.error('Logout error:', error);
            }
            window.location.href = 'login.html';
        });
    }
}

/**
 * ============================================
 * CHECK-IN PAGE FUNCTIONALITY
 * ============================================
 */

/**
 * Checks member status by querying the backend API
 * Updates the membership status display in real-time
 * @param {string} memberId - The member ID to check
 */
async function checkMemberStatus(memberId) {
    try {
        const statusValue = document.getElementById('status-value');
        if (!statusValue) return;

        const response = await fetch(`${API_BASE_URL}/api/members/${memberId}/status`, {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (response.ok) {
            const data = await response.json();
            // Update status display with member's current status
            statusValue.textContent = data.status || 'Unknown';
            
            // Apply appropriate CSS class based on status
            if (data.status === 'Active') {
                statusValue.className = 'status-value';
            } else if (data.status === 'Inactive' || data.status === 'Expired') {
                statusValue.className = 'status-value ' + data.status.toLowerCase();
            }
        } else {
            // Show "Not Found" if member doesn't exist
            statusValue.textContent = 'Not Found';
            statusValue.className = 'status-value inactive';
        }
    } catch (error) {
        console.error('Error checking member status:', error);
    }
}

/**
 * Loads recent check-ins from the backend API
 * Updates the recent check-ins panel
 */
async function loadRecentCheckins() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/checkin/recent`, {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (response.ok) {
            const data = await response.json();
            updateRecentCheckinsList(data.checkins || []);
        }
    } catch (error) {
        console.error('Error loading recent check-ins:', error);
    }
}

/**
 * Updates the recent check-ins list in the UI
 * @param {Array} checkins - Array of check-in records
 */
function updateRecentCheckinsList(checkins) {
    const list = document.getElementById('checkins-list');
    if (!list) return;

    if (checkins.length === 0) {
        list.innerHTML = '<li class="checkin-item">No recent check-ins</li>';
        return;
    }

    // Format and display each check-in with member name and time
    list.innerHTML = checkins.map(checkin => {
        const time = new Date(checkin.checkInTime).toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        return `<li class="checkin-item">${checkin.memberName} - ${time}</li>`;
    }).join('');
}

/**
 * Handles member check-in form submission
 * Validates input, sends check-in request to API, and displays result
 * @param {string} memberId - The member ID to check in
 */
async function handleCheckIn(memberId) {
    const checkinButton = document.getElementById('checkin-button');
    const memberIdInput = document.getElementById('member-id');
    const statusValue = document.getElementById('status-value');

    try {
        if (checkinButton) {
            checkinButton.disabled = true;
            checkinButton.textContent = 'Processing...';
        }

        const response = await fetch(`${API_BASE_URL}/api/checkin`, {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ memberId: memberId })
        });

        // Parse JSON response
        const data = await response.json();

        if (response.ok && data.success) {
            const memberNameEl = document.getElementById('checked-in-member-name');
            if (memberNameEl && data.checkIn && data.checkIn.memberName) {
                memberNameEl.textContent = data.checkIn.memberName;
            }
            showCheckInSuccess();
            
            if (memberIdInput) memberIdInput.value = '';
            if (statusValue) {
                statusValue.textContent = '-';
                statusValue.className = 'status-value';
            }
            
            loadRecentCheckins();
            
            setTimeout(() => {
                hideCheckInSuccess();
            }, 5000);
        } else {
            showCheckInError(data.message || 'Check-in failed. Please try again.');
        }
    } catch (error) {
        // Handle network errors or other exceptions
        console.error('Check-in error:', error);
        showCheckInError('An error occurred. Please try again later.');
    } finally {
        // Re-enable button regardless of success or failure
        if (checkinButton) {
            checkinButton.disabled = false;
            checkinButton.textContent = 'Check-In';
        }
    }
}

/**
 * Displays success message for check-in
 */
function showCheckInSuccess() {
    const successMessage = document.getElementById('success-message');
    const errorMessage = document.getElementById('error-message');
    
    if (successMessage) {
        successMessage.style.display = 'flex';
        successMessage.classList.add('show');
    }
    
    // Hide any error messages
    if (errorMessage) {
        errorMessage.style.display = 'none';
        errorMessage.classList.remove('show');
    }
}

/**
 * Hides the success message
 */
function hideCheckInSuccess() {
    const successMessage = document.getElementById('success-message');
    if (successMessage) {
        successMessage.style.display = 'none';
        successMessage.classList.remove('show');
    }
}

/**
 * Displays error message for check-in
 * @param {string} message - The error message to display
 */
function showCheckInError(message) {
    const errorMessage = document.getElementById('error-message');
    if (errorMessage) {
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';
        errorMessage.classList.add('show');
    }
    hideCheckInSuccess();
}

/**
 * Hides both success and error messages
 */
function hideCheckInMessages() {
    hideCheckInSuccess();
    const errorMessage = document.getElementById('error-message');
    if (errorMessage) {
        errorMessage.style.display = 'none';
        errorMessage.classList.remove('show');
    }
}

/**
 * Initializes check-in page functionality
 * Sets up form handlers, member status checking, and authentication
 */
async function initializeCheckInPage() {
    const checkinForm = document.getElementById('checkin-form');
    if (!checkinForm) return;

    if (!(await checkAuthentication())) {
        return;
    }

    // Get form elements
    const memberIdInput = document.getElementById('member-id');
    const statusValue = document.getElementById('status-value');
    const dismissButton = document.getElementById('dismiss-button');
    
    if (!memberIdInput || !statusValue) return;

    // Load recent check-ins on page load
    loadRecentCheckins();

    // Real-time member status checking with debounce
    // Checks member status as user types (after 500ms delay)
    let memberStatusTimeout;
    memberIdInput.addEventListener('input', function() {
        clearTimeout(memberStatusTimeout);
        const memberId = memberIdInput.value.trim();
        
        // Only check status if at least 3 characters entered
        if (memberId.length >= 3) {
            memberStatusTimeout = setTimeout(() => {
                checkMemberStatus(memberId);
            }, 500);
        } else {
            // Reset status display if input is too short
            statusValue.textContent = '-';
            statusValue.className = 'status-value';
        }
    });

    // Handle check-in form submission
    checkinForm.addEventListener('submit', async function(e) {
        // Prevent default form submission
        e.preventDefault();
        hideCheckInMessages();

        const memberId = memberIdInput.value.trim();
        
        // Validate that member ID is entered
        if (!memberId) {
            showCheckInError('Please enter a Member ID');
            return;
        }

        // Process check-in request
        await handleCheckIn(memberId);
    });

    // Set up dismiss button for success message
    if (dismissButton) {
        dismissButton.addEventListener('click', hideCheckInSuccess);
    }
}

/**
 * ============================================
 * ATTENDANCE PAGE FUNCTIONALITY
 * ============================================
 */

/**
 * Generates sample attendance data for demonstration purposes
 * Returns an array of attendance records with realistic data
 * @returns {Array} Array of sample attendance records
 */
function getSampleAttendanceData() {
    // Sample attendance records with various dates and times
    const sampleData = [
        { memberId: '001', memberName: 'John Doe', checkInDate: '2024-01-15', checkInTime: '2024-01-15T08:30:00', status: 'Checked-in' },
        { memberId: '002', memberName: 'Jane Smith', checkInDate: '2024-01-15', checkInTime: '2024-01-15T09:15:00', status: 'Checked-in' },
        { memberId: '003', memberName: 'Mike Johnson', checkInDate: '2024-01-15', checkInTime: '2024-01-15T10:00:00', status: 'Checked-in' },
        { memberId: '004', memberName: 'Sarah Williams', checkInDate: '2024-01-15', checkInTime: '2024-01-15T10:45:00', status: 'Checked-in' },
        { memberId: '005', memberName: 'David Brown', checkInDate: '2024-01-15', checkInTime: '2024-01-15T11:30:00', status: 'Checked-in' },
        { memberId: '006', memberName: 'Emily Davis', checkInDate: '2024-01-15', checkInTime: '2024-01-15T12:15:00', status: 'Checked-in' },
        { memberId: '007', memberName: 'Robert Wilson', checkInDate: '2024-01-15', checkInTime: '2024-01-15T13:00:00', status: 'Checked-in' },
        { memberId: '008', memberName: 'Lisa Anderson', checkInDate: '2024-01-15', checkInTime: '2024-01-15T13:45:00', status: 'Checked-in' },
        { memberId: '009', memberName: 'Michael Taylor', checkInDate: '2024-01-15', checkInTime: '2024-01-15T14:30:00', status: 'Checked-in' },
        { memberId: '010', memberName: 'Jennifer Martinez', checkInDate: '2024-01-15', checkInTime: '2024-01-15T15:15:00', status: 'Checked-in' },
        { memberId: '011', memberName: 'Christopher Lee', checkInDate: '2024-01-14', checkInTime: '2024-01-14T08:00:00', status: 'Checked-in' },
        { memberId: '012', memberName: 'Amanda White', checkInDate: '2024-01-14', checkInTime: '2024-01-14T09:30:00', status: 'Checked-in' },
        { memberId: '013', memberName: 'Daniel Harris', checkInDate: '2024-01-14', checkInTime: '2024-01-14T10:15:00', status: 'Checked-in' },
        { memberId: '014', memberName: 'Michelle Clark', checkInDate: '2024-01-14', checkInTime: '2024-01-14T11:00:00', status: 'Checked-in' },
        { memberId: '015', memberName: 'James Lewis', checkInDate: '2024-01-14', checkInTime: '2024-01-14T12:00:00', status: 'Checked-in' }
    ];
    return sampleData;
}

/**
 * Loads attendance history from the backend API
 * Falls back to sample data if API is unavailable
 * Updates the attendance table with fetched or sample data
 */
async function loadAttendanceHistory() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/attendance/history`, {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        // If API call succeeds, use the data from API
        if (response.ok) {
            const data = await response.json();
            updateAttendanceTable(data.attendance || []);
        } else {
            // If API fails, use sample data for demonstration
            console.log('API unavailable, using sample attendance data');
            const sampleData = getSampleAttendanceData();
            updateAttendanceTable(sampleData);
        }
    } catch (error) {
        // If network error occurs, use sample data
        console.error('Error loading attendance history:', error);
        const sampleData = getSampleAttendanceData();
        updateAttendanceTable(sampleData);
    }
}

/**
 * Updates the attendance table with new data
 * Formats dates and times for display
 * @param {Array} attendance - Array of attendance records
 */
function updateAttendanceTable(attendance) {
    const tbody = document.getElementById('attendance-tbody');
    if (!tbody) return;

    if (attendance.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 20px;">No attendance records found</td></tr>';
        return;
    }

    // Format and display each attendance record
    tbody.innerHTML = attendance.map(record => {
        // Format date (assuming ISO format from API)
        const date = new Date(record.checkInDate);
        const formattedDate = date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });

        // Format time
        const time = new Date(record.checkInTime || record.checkInDate);
        const formattedTime = time.toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });

        return `
            <tr>
                <td>${record.memberId || record.id}</td>
                <td>${record.memberName}</td>
                <td>${formattedDate}</td>
                <td>${formattedTime}</td>
                <td><span class="status-badge status-checked-in">${record.status || 'Checked-in'}</span></td>
            </tr>
        `;
    }).join('');
}

/**
 * Initializes attendance page functionality
 * Checks authentication, loads attendance data, and sets up event handlers
 * Reuses existing utility functions for authentication and user info
 */
async function initializeAttendancePage() {
    const attendanceTbody = document.getElementById('attendance-tbody');
    if (!attendanceTbody) return;

    if (!(await checkAuthentication())) {
        return;
    }

    // Load attendance history (will use sample data if API unavailable)
    // Reuses updateAttendanceTable function to populate the table
    loadAttendanceHistory();

    loadUserInfo();

    const logoutLink = document.getElementById('logout-link');
    if (logoutLink) {
        logoutLink.addEventListener('click', async function(e) {
            e.preventDefault();
            try {
                await fetch(`${API_BASE_URL}/api/auth/logout`, {
                    method: 'POST',
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            } catch (error) {
                console.error('Logout error:', error);
            }
            window.location.href = 'login.html';
        });
    }
}

/**
 * ============================================
 * REPORTS PAGE FUNCTIONALITY
 * ============================================
 */

/**
 * Generates sample report summary data for demonstration purposes
 * Returns an object with summary metrics
 * @returns {Object} Object containing report summary values
 */
function getSampleReportSummary() {
    // Sample report summary with realistic values
    return {
        totalMembers: 120,
        dailyAttendance: 35,
        expiredMemberships: 5
    };
}

/**
 * Loads report summary data from the backend API
 * Falls back to sample data if API is unavailable
 * Updates the summary metrics cards with fetched or sample data
 */
async function loadReportSummary() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/reports/summary`, {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        // If API call succeeds, use the data from API
        if (response.ok) {
            const data = await response.json();
            updateReportSummary(data);
        } else {
            // If API fails, use sample data for demonstration
            console.log('API unavailable, using sample report summary data');
            const sampleData = getSampleReportSummary();
            updateReportSummary(sampleData);
        }
    } catch (error) {
        // If network error occurs, use sample data
        console.error('Error loading report summary:', error);
        const sampleData = getSampleReportSummary();
        updateReportSummary(sampleData);
    }
}

/**
 * Updates the report summary metrics with new data
 * @param {Object} data - Object containing report summary values
 */
function updateReportSummary(data) {
    if (data.totalMembers !== undefined) {
        const element = document.getElementById('report-total-members');
        if (element) element.textContent = data.totalMembers;
    }
    if (data.dailyAttendance !== undefined) {
        const element = document.getElementById('report-daily-attendance');
        if (element) element.textContent = data.dailyAttendance;
    }
    if (data.expiredMemberships !== undefined) {
        const element = document.getElementById('report-expired-memberships');
        if (element) element.textContent = data.expiredMemberships;
    }
}

/**
 * Generates sample report history data for demonstration purposes
 * Returns an array of report records with realistic data
 * @returns {Array} Array of sample report records
 */
function getSampleReportHistory() {
    // Sample report records with various types and dates
    const sampleReports = [
        { reportId: 'RPT-001', reportType: 'Attendance Report', generatedDate: '2024-01-15', period: 'January 2024', status: 'Generated' },
        { reportId: 'RPT-002', reportType: 'Membership Report', generatedDate: '2024-01-14', period: 'December 2023', status: 'Generated' },
        { reportId: 'RPT-003', reportType: 'Financial Report', generatedDate: '2024-01-13', period: 'Q4 2023', status: 'Generated' },
        { reportId: 'RPT-004', reportType: 'Attendance Report', generatedDate: '2024-01-12', period: 'December 2023', status: 'Generated' },
        { reportId: 'RPT-005', reportType: 'Membership Report', generatedDate: '2024-01-11', period: 'November 2023', status: 'Generated' }
    ];
    return sampleReports;
}

/**
 * Loads report history from the backend API
 * Falls back to sample data if API is unavailable
 * Updates the reports table with fetched or sample data
 */
async function loadReportHistory() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/reports/history`, {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        // If API call succeeds, use the data from API
        if (response.ok) {
            const data = await response.json();
            updateReportsTable(data.reports || []);
        } else {
            // If API fails, use sample data for demonstration
            console.log('API unavailable, using sample report history data');
            const sampleData = getSampleReportHistory();
            updateReportsTable(sampleData);
        }
    } catch (error) {
        // If network error occurs, use sample data
        console.error('Error loading report history:', error);
        const sampleData = getSampleReportHistory();
        updateReportsTable(sampleData);
    }
}

/**
 * Updates the reports table with new data
 * @param {Array} reports - Array of report records
 */
function updateReportsTable(reports) {
    const tbody = document.getElementById('reports-tbody');
    if (!tbody) return;

    if (reports.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 20px;">No reports found</td></tr>';
        return;
    }

    // Format and display each report record
    tbody.innerHTML = reports.map(report => {
        const date = new Date(report.generatedDate);
        const formattedDate = date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });

        return `
            <tr>
                <td>${report.reportId || report.id}</td>
                <td>${report.reportType}</td>
                <td>${formattedDate}</td>
                <td>${report.period}</td>
                <td><span class="status-badge status-checked-in">${report.status || 'Generated'}</span></td>
            </tr>
        `;
    }).join('');
}

/**
 * Handles report generation request
 * Sends request to backend API to generate a new report
 * @param {string} reportType - Type of report to generate (attendance, membership, financial)
 */
async function generateReport(reportType) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/reports/generate`, {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ reportType: reportType })
        });

        if (response.ok) {
            const data = await response.json();
            // Show success message (could be enhanced with a toast notification)
            alert(`Report generated successfully! Report ID: ${data.reportId || 'N/A'}`);
            // Reload report history to show new report
            loadReportHistory();
        } else {
            const errorData = await response.json();
            alert(`Failed to generate report: ${errorData.message || 'Unknown error'}`);
        }
    } catch (error) {
        console.error('Error generating report:', error);
        alert('An error occurred while generating the report. Please try again later.');
    }
}

/**
 * Initializes reports page functionality
 * Sets up report generation buttons and loads report data
 * Reuses existing utility functions for authentication and data loading
 */
async function initializeReportsPage() {
    const reportsTbody = document.getElementById('reports-tbody');
    if (!reportsTbody) return;

    if (!(await checkAuthentication())) {
        return;
    }

    // Load report summary (will use sample data if API unavailable)
    // Reuses updateReportSummary function to populate the metrics
    loadReportSummary();

    // Load report history (will use sample data if API unavailable)
    // Reuses updateReportsTable function to populate the table
    loadReportHistory();

    // Load user info for welcome message using existing function
    loadUserInfo();

    // Set up report generation buttons with event handlers
    const attendanceReportBtn = document.getElementById('generate-attendance-report');
    const membershipReportBtn = document.getElementById('generate-membership-report');
    const financialReportBtn = document.getElementById('generate-financial-report');

    // Attach click handlers to each report generation button
    if (attendanceReportBtn) {
        attendanceReportBtn.addEventListener('click', function() {
            generateReport('attendance');
        });
    }

    if (membershipReportBtn) {
        membershipReportBtn.addEventListener('click', function() {
            generateReport('membership');
        });
    }

    if (financialReportBtn) {
        financialReportBtn.addEventListener('click', function() {
            generateReport('financial');
        });
    }

    const logoutLink = document.getElementById('logout-link');
    if (logoutLink) {
        logoutLink.addEventListener('click', async function(e) {
            e.preventDefault();
            try {
                await fetch(`${API_BASE_URL}/api/auth/logout`, {
                    method: 'POST',
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            } catch (error) {
                console.error('Logout error:', error);
            }
            window.location.href = 'login.html';
        });
    }
}

/**
 * ============================================
 * PAGE INITIALIZATION
 * ============================================
 */

/**
 * Main initialization function
 * Runs when DOM is fully loaded
 * Detects which page is active and initializes appropriate functionality
 */
document.addEventListener('DOMContentLoaded', function() {
    // Initialize login page if login form exists
    initializeLoginPage();
    
    // Initialize dashboard page if dashboard main exists
    initializeDashboardPage();
    
    // Initialize check-in page if check-in form exists
    initializeCheckInPage();
    
    // Initialize attendance page if attendance table exists
    initializeAttendancePage();
    
    // Initialize reports page if reports table exists
    initializeReportsPage();
});
