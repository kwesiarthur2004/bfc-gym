// Body Fitness Center - Express Server
// Invitation-based access system

const express = require('express');
const path = require('path');
const cors = require('cors');
const session = require('express-session');

const authRoutes = require('./routes/auth');
const memberRoutes = require('./routes/members');
const checkinRoutes = require('./routes/checkin');
const dashboardRoutes = require('./routes/dashboard');
const attendanceRoutes = require('./routes/attendance');
const reportsRoutes = require('./routes/reports');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors({
    origin: process.env.FRONTEND_URL || `http://localhost:${PORT}`,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: process.env.SESSION_SECRET || 'bfc-gym-secret-key-change-in-production',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: process.env.NODE_ENV === 'production',
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000
    }
}));

// Routes
app.get('/health', (req, res) => {
    res.status(200).json({ 
        status: 'OK', 
        message: 'Server is running',
        timestamp: new Date().toISOString()
    });
});

app.get('/api', (req, res) => {
    res.status(200).json({
        message: 'Body Fitness Center API',
        version: '1.0.0',
        endpoints: {
            auth: '/api/auth',
            members: '/api/members',
            checkin: '/api/checkin',
            dashboard: '/api/dashboard',
            attendance: '/api/attendance',
            reports: '/api/reports'
        }
    });
});

// API Routes (must come before static file serving)
app.use('/api/auth', authRoutes);
app.use('/api/members', memberRoutes);
app.use('/api/checkin', checkinRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/reports', reportsRoutes);

// 404 handler for API routes
app.use('/api/*', (req, res) => {
    res.status(404).json({
        error: 'Not Found',
        message: `The requested API route ${req.method} ${req.path} does not exist`,
        availableEndpoints: '/api'
    });
});

// Serve static files from frontend directory (CSS, JS, images, etc.)
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// Serve login.html for root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'frontend', 'login.html'));
});

// Serve HTML files directly
app.get('*.html', (req, res) => {
    const filePath = path.join(__dirname, '..', 'frontend', req.path);
    res.sendFile(filePath, (err) => {
        if (err) {
            res.status(404).sendFile(path.join(__dirname, '..', 'frontend', 'login.html'));
        }
    });
});

app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(err.status || 500).json({
        error: err.message || 'Internal Server Error',
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
    });
});

// Start server
const server = app.listen(PORT, () => {
    console.log('='.repeat(50));
    console.log('Body Fitness Center - Server Started');
    console.log('='.repeat(50));
    console.log(`Server running on port ${PORT}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`Health check: http://localhost:${PORT}/health`);
    console.log(`API root: http://localhost:${PORT}/api`);
    console.log(`Frontend: http://localhost:${PORT}/login.html`);
    console.log(`Open in browser: http://localhost:${PORT}`);
    console.log('='.repeat(50));
});

server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error(`\n❌ Error: Port ${PORT} is already in use.`);
        console.error('Please either:');
        console.error(`  1. Stop the process using port ${PORT}`);
        console.error('  2. Change the PORT in your .env file');
        console.error('\nTo find and kill the process:');
        console.error(`  netstat -ano | findstr :${PORT}`);
        console.error('  taskkill /PID <PID> /F\n');
        process.exit(1);
    } else {
        console.error('Server error:', err);
        process.exit(1);
    }
});

module.exports = app;
