// Check-In Routes - Invitation-based access system

const express = require('express');
const router = express.Router();
const { requireAuth } = require('./auth');

// Mock members data (shared with members route)
const mockMembers = [
    {
        id: 1,
        member_id: 'MEM-10001',
        first_name: 'John',
        last_name: 'Doe',
        email: 'john.doe@email.com',
        phone: '555-0101',
        membership_type: 'Premium',
        status: 'Active',
        start_date: '2024-01-15',
        expiration_date: '2025-01-15',
        created_at: '2024-01-15T10:00:00.000Z'
    },
    {
        id: 2,
        member_id: 'MEM-10002',
        first_name: 'Jane',
        last_name: 'Smith',
        email: 'jane.smith@email.com',
        phone: '555-0102',
        membership_type: 'Standard',
        status: 'Active',
        start_date: '2024-02-01',
        expiration_date: '2025-02-01',
        created_at: '2024-02-01T10:00:00.000Z'
    },
    {
        id: 3,
        member_id: 'MEM-10003',
        first_name: 'Mike',
        last_name: 'Johnson',
        email: 'mike.johnson@email.com',
        phone: '555-0103',
        membership_type: 'Premium',
        status: 'Active',
        start_date: '2023-12-01',
        expiration_date: '2024-12-01',
        created_at: '2023-12-01T10:00:00.000Z'
    },
    {
        id: 4,
        member_id: 'MEM-10004',
        first_name: 'Sarah',
        last_name: 'Williams',
        email: 'sarah.williams@email.com',
        phone: '555-0104',
        membership_type: 'Basic',
        status: 'Inactive',
        start_date: '2023-11-01',
        expiration_date: '2024-11-01',
        created_at: '2023-11-01T10:00:00.000Z'
    },
    {
        id: 5,
        member_id: 'MEM-10005',
        first_name: 'David',
        last_name: 'Brown',
        email: 'david.brown@email.com',
        phone: '555-0105',
        membership_type: 'Standard',
        status: 'Active',
        start_date: '2024-03-15',
        expiration_date: '2025-03-15',
        created_at: '2024-03-15T10:00:00.000Z'
    }
];

// Mock check-ins data
let mockCheckins = [
    {
        id: 1,
        member_id: 1,
        check_in_date: '2024-12-15',
        check_in_time: '2024-12-15T08:30:00.000Z',
        status: 'Checked-in'
    },
    {
        id: 2,
        member_id: 2,
        check_in_date: '2024-12-15',
        check_in_time: '2024-12-15T09:15:00.000Z',
        status: 'Checked-in'
    },
    {
        id: 3,
        member_id: 1,
        check_in_date: '2024-12-14',
        check_in_time: '2024-12-14T18:00:00.000Z',
        status: 'Checked-in'
    },
    {
        id: 4,
        member_id: 3,
        check_in_date: '2024-12-14',
        check_in_time: '2024-12-14T19:30:00.000Z',
        status: 'Checked-in'
    },
    {
        id: 5,
        member_id: 5,
        check_in_date: '2024-12-13',
        check_in_time: '2024-12-13T07:45:00.000Z',
        status: 'Checked-in'
    }
];

let nextCheckinId = 6;

// Helper function to get member by ID or member_id
function findMember(memberId) {
    return mockMembers.find(m => m.id === parseInt(memberId) || m.member_id === memberId);
}

// POST /api/checkin - Record member check-in
router.post('/', requireAuth, (req, res) => {
    try {
        const { memberId } = req.body;

        if (!memberId) {
            return res.status(400).json({
                success: false,
                message: 'Member ID is required'
            });
        }

        const member = findMember(memberId);

        if (!member) {
            return res.status(404).json({
                success: false,
                message: 'Member not found. Please verify the Member ID.'
            });
        }

        if (member.status !== 'Active') {
            return res.status(403).json({
                success: false,
                message: `Member status is ${member.status}. Only active members can check in.`
            });
        }

        if (member.expiration_date) {
            const expirationDate = new Date(member.expiration_date);
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            if (expirationDate < today) {
                return res.status(403).json({
                    success: false,
                    message: 'Membership has expired. Please renew membership to check in.'
                });
            }
        }

        const checkInDateTime = new Date();
        const checkInDate = checkInDateTime.toISOString().split('T')[0];
        const checkInTime = checkInDateTime.toISOString();

        const newCheckin = {
            id: nextCheckinId++,
            member_id: member.id,
            check_in_date: checkInDate,
            check_in_time: checkInTime,
            status: 'Checked-in'
        };

        mockCheckins.unshift(newCheckin);

        res.status(200).json({
            success: true,
            message: 'Check-in recorded successfully',
            checkIn: {
                memberId: member.member_id,
                memberName: `${member.first_name} ${member.last_name}`,
                checkInDate: checkInDate,
                checkInTime: checkInTime,
                status: 'Checked-in',
                membershipType: member.membership_type
            }
        });

    } catch (error) {
        console.error('Check-in error:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred while recording check-in. Please try again later.'
        });
    }
});

// GET /api/checkin/recent - Get recent check-ins
router.get('/recent', requireAuth, (req, res) => {
    try {
        const limit = Math.min(parseInt(req.query.limit) || 10, 50);

        const formattedCheckins = mockCheckins
            .slice(0, limit)
            .map(checkin => {
                const member = members.find(m => m.id === checkin.member_id);
                return {
                    id: checkin.id,
                    memberId: member ? member.member_id : checkin.member_id,
                    memberName: member ? `${member.first_name} ${member.last_name}` : 'Unknown',
                    checkInDate: checkin.check_in_date,
                    checkInTime: checkin.check_in_time,
                    status: checkin.status
                };
            })
            .filter(c => c.memberName !== 'Unknown');

        res.status(200).json({
            success: true,
            checkins: formattedCheckins,
            total: formattedCheckins.length
        });

    } catch (error) {
        console.error('Error retrieving recent check-ins:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred while retrieving recent check-ins'
        });
    }
});

// GET /api/checkin/history - Get check-in history
router.get('/history', requireAuth, (req, res) => {
    try {
        const { memberId, startDate, endDate, page = 1, limit = 50 } = req.query;

        let filteredCheckins = [...mockCheckins];

        if (memberId) {
            const member = findMember(memberId);
            if (member) {
                filteredCheckins = filteredCheckins.filter(c => c.member_id === member.id);
            } else {
                filteredCheckins = [];
            }
        }

        if (startDate) {
            filteredCheckins = filteredCheckins.filter(c => c.check_in_date >= startDate);
        }

        if (endDate) {
            filteredCheckins = filteredCheckins.filter(c => c.check_in_date <= endDate);
        }

        const total = filteredCheckins.length;
        const offset = (parseInt(page) - 1) * parseInt(limit);
        const paginatedCheckins = filteredCheckins
            .sort((a, b) => new Date(b.check_in_time) - new Date(a.check_in_time))
            .slice(offset, offset + parseInt(limit));

        const formattedCheckins = paginatedCheckins.map(checkin => {
            const member = members.find(m => m.id === checkin.member_id);
            return {
                id: checkin.id,
                memberId: member ? member.member_id : checkin.member_id,
                memberName: member ? `${member.first_name} ${member.last_name}` : 'Unknown',
                checkInDate: checkin.check_in_date,
                checkInTime: checkin.check_in_time,
                status: checkin.status
            };
        }).filter(c => c.memberName !== 'Unknown');

        res.status(200).json({
            success: true,
            checkins: formattedCheckins,
            total: total,
            page: parseInt(page),
            limit: parseInt(limit),
            totalPages: Math.ceil(total / parseInt(limit))
        });

    } catch (error) {
        console.error('Error retrieving check-in history:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred while retrieving check-in history'
        });
    }
});

module.exports = router;
