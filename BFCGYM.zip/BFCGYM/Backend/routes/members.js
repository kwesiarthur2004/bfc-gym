// Member Routes - Invitation-based access system

const express = require('express');
const router = express.Router();
const { requireAuth } = require('./auth');

// Mock members data
let mockMembers = [
    {
        id: 1,
        member_id: 'MEM-10001',
        first_name: 'John',
        last_name: 'Doe',
        email: 'john.doe@email.com',
        phone: '555-0101',
        membership_type: 'Premium',
        status: 'Active',
        start_date: '2024-01-15',
        expiration_date: '2025-01-15',
        created_at: '2024-01-15T10:00:00.000Z'
    },
    {
        id: 2,
        member_id: 'MEM-10002',
        first_name: 'Jane',
        last_name: 'Smith',
        email: 'jane.smith@email.com',
        phone: '555-0102',
        membership_type: 'Standard',
        status: 'Active',
        start_date: '2024-02-01',
        expiration_date: '2025-02-01',
        created_at: '2024-02-01T10:00:00.000Z'
    },
    {
        id: 3,
        member_id: 'MEM-10003',
        first_name: 'Mike',
        last_name: 'Johnson',
        email: 'mike.johnson@email.com',
        phone: '555-0103',
        membership_type: 'Premium',
        status: 'Active',
        start_date: '2023-12-01',
        expiration_date: '2024-12-01',
        created_at: '2023-12-01T10:00:00.000Z'
    },
    {
        id: 4,
        member_id: 'MEM-10004',
        first_name: 'Sarah',
        last_name: 'Williams',
        email: 'sarah.williams@email.com',
        phone: '555-0104',
        membership_type: 'Basic',
        status: 'Inactive',
        start_date: '2023-11-01',
        expiration_date: '2024-11-01',
        created_at: '2023-11-01T10:00:00.000Z'
    },
    {
        id: 5,
        member_id: 'MEM-10005',
        first_name: 'David',
        last_name: 'Brown',
        email: 'david.brown@email.com',
        phone: '555-0105',
        membership_type: 'Standard',
        status: 'Active',
        start_date: '2024-03-15',
        expiration_date: '2025-03-15',
        created_at: '2024-03-15T10:00:00.000Z'
    }
];

let nextMemberId = 6;

// Export function to get mock members (for use in other routes)
function getMockMembers() {
    return mockMembers;
}

module.exports.getMockMembers = getMockMembers;

// GET /api/members - Get all members
router.get('/', requireAuth, (req, res) => {
    try {
        const { status, page = 1, limit = 50 } = req.query;
        let filteredMembers = [...mockMembers];

        if (status) {
            filteredMembers = filteredMembers.filter(m => m.status === status);
        }

        const total = filteredMembers.length;
        const offset = (parseInt(page) - 1) * parseInt(limit);
        const paginatedMembers = filteredMembers
            .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
            .slice(offset, offset + parseInt(limit));

        res.status(200).json({
            success: true,
            members: paginatedMembers,
            total: total,
            page: parseInt(page),
            limit: parseInt(limit),
            totalPages: Math.ceil(total / parseInt(limit))
        });

    } catch (error) {
        console.error('Error retrieving members:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred while retrieving members'
        });
    }
});

// GET /api/members/:id - Get member by ID
router.get('/:id', requireAuth, (req, res) => {
    try {
        const { id } = req.params;
        const member = mockMembers.find(m => m.id === parseInt(id) || m.member_id === id);

        if (!member) {
            return res.status(404).json({
                success: false,
                message: 'Member not found'
            });
        }

        res.status(200).json({
            success: true,
            member: member
        });

    } catch (error) {
        console.error('Error retrieving member:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred while retrieving member'
        });
    }
});

// GET /api/members/:id/status - Get member status
router.get('/:id/status', requireAuth, (req, res) => {
    try {
        const { id } = req.params;
        const member = mockMembers.find(m => m.id === parseInt(id) || m.member_id === id);

        if (!member) {
            return res.status(404).json({
                success: false,
                message: 'Member not found',
                memberId: id,
                status: 'Not Found'
            });
        }

        let status = member.status;

        if (member.expiration_date) {
            const expirationDate = new Date(member.expiration_date);
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            if (expirationDate < today && status === 'Active') {
                status = 'Expired';
            }
        }

        res.status(200).json({
            success: true,
            memberId: member.member_id,
            status: status,
            membershipType: member.membership_type || 'Standard',
            expirationDate: member.expiration_date || null
        });

    } catch (error) {
        console.error('Error retrieving member status:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred while retrieving member status'
        });
    }
});

// POST /api/members - Create new member
router.post('/', requireAuth, (req, res) => {
    try {
        const { first_name, last_name, email, phone, membership_type, start_date, expiration_date } = req.body;

        if (!first_name || !last_name || !email || !membership_type) {
            return res.status(400).json({
                success: false,
                message: 'Missing required fields. Please provide: first_name, last_name, email, and membership_type'
            });
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid email format'
            });
        }

        const emailExists = mockMembers.find(m => m.email === email);
        if (emailExists) {
            return res.status(409).json({
                success: false,
                message: 'A member with this email already exists'
            });
        }

        const memberIdPrefix = 'MEM-';
        const randomSuffix = Math.floor(10000 + Math.random() * 90000);
        const member_id = memberIdPrefix + randomSuffix;
        const memberStartDate = start_date || new Date().toISOString().split('T')[0];

        const newMember = {
            id: nextMemberId++,
            member_id: member_id,
            first_name: first_name,
            last_name: last_name,
            email: email,
            phone: phone || null,
            membership_type: membership_type,
            status: 'Active',
            start_date: memberStartDate,
            expiration_date: expiration_date || null,
            created_at: new Date().toISOString()
        };

        mockMembers.push(newMember);

        res.status(201).json({
            success: true,
            message: 'Member created successfully',
            member: newMember
        });

    } catch (error) {
        console.error('Error creating member:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred while creating member'
        });
    }
});

// PUT /api/members/:id - Update member
router.put('/:id', requireAuth, (req, res) => {
    try {
        const { id } = req.params;
        const updateData = req.body;

        const memberIndex = mockMembers.findIndex(m => m.id === parseInt(id) || m.member_id === id);

        if (memberIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Member not found'
            });
        }

        const allowedFields = ['first_name', 'last_name', 'email', 'phone', 'membership_type', 'status', 'expiration_date'];
        const member = mockMembers[memberIndex];

        for (const field of allowedFields) {
            if (updateData[field] !== undefined) {
                member[field] = updateData[field];
            }
        }

        res.status(200).json({
            success: true,
            message: 'Member updated successfully',
            member: member
        });

    } catch (error) {
        console.error('Error updating member:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred while updating member'
        });
    }
});

// DELETE /api/members/:id - Delete member
router.delete('/:id', requireAuth, (req, res) => {
    try {
        const { id } = req.params;

        const memberIndex = mockMembers.findIndex(m => m.id === parseInt(id) || m.member_id === id);

        if (memberIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Member not found'
            });
        }

        mockMembers.splice(memberIndex, 1);

        res.status(200).json({
            success: true,
            message: 'Member deleted successfully'
        });

    } catch (error) {
        console.error('Error deleting member:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred while deleting member'
        });
    }
});

module.exports = router;
