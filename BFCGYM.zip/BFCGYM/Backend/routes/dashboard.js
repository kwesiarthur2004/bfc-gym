// Dashboard Routes - Invitation-based access system

const express = require('express');
const router = express.Router();
const { requireAuth } = require('./auth');
const { getMockMembers } = require('./members');

// Helper to get checkins (would be imported from checkin route in real app)
function getMockCheckins() {
    // This is a simplified version - in production, checkins would be in a shared store
    return [];
}

router.get('/stats', requireAuth, (req, res) => {
    try {
        const members = getMockMembers();
        const today = new Date().toISOString().split('T')[0];
        
        const totalMembers = members.length;
        const activeMembers = members.filter(m => m.status === 'Active').length;
        const expiredMemberships = members.filter(m => {
            if (!m.expiration_date) return false;
            const expDate = new Date(m.expiration_date);
            const todayDate = new Date();
            todayDate.setHours(0, 0, 0, 0);
            return expDate < todayDate;
        }).length;

        // Mock recent attendance (would come from checkins in real app)
        const recentAttendance = [
            { id: '001', memberName: 'John Doe', checkInTime: '2024-12-15 08:30' },
            { id: '002', memberName: 'Jane Smith', checkInTime: '2024-12-15 09:15' },
            { id: '003', memberName: 'Mike Johnson', checkInTime: '2024-12-15 10:00' }
        ];

        // Mock expirations
        const expirations = members
            .filter(m => m.expiration_date)
            .sort((a, b) => new Date(a.expiration_date) - new Date(b.expiration_date))
            .slice(0, 5)
            .map(m => ({
                id: m.member_id,
                memberName: `${m.first_name} ${m.last_name}`,
                expirationDate: m.expiration_date
            }));

        res.status(200).json({
            totalMembers: totalMembers,
            checkedInToday: recentAttendance.length,
            expiredMemberships: expiredMemberships,
            totalStaff: 8,
            recentAttendance: recentAttendance,
            expirations: expirations
        });
    } catch (error) {
        console.error('Error retrieving dashboard stats:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred while retrieving dashboard statistics'
        });
    }
});

module.exports = router;
