// Authentication Routes - Invitation-based access system
// Access restricted to: Receptionists, Trainers, and Managers

const express = require('express');
const router = express.Router();

// Allowed roles
const ALLOWED_ROLES = ['receptionist', 'trainer', 'manager'];

// Mock invitations - Role-specific
const mockInvitations = [
    {
        code: 'RECEPTION-2024',
        status: 'active',
        maxUses: 20,
        usedCount: 5,
        expiresAt: '2025-12-31',
        role: 'receptionist',
        createdBy: 'system'
    },
    {
        code: 'TRAINER-2024',
        status: 'active',
        maxUses: 15,
        usedCount: 3,
        expiresAt: '2025-12-31',
        role: 'trainer',
        createdBy: 'system'
    },
    {
        code: 'MANAGER-2024',
        status: 'active',
        maxUses: 10,
        usedCount: 2,
        expiresAt: null, // Non-expiring admin code
        role: 'manager',
        createdBy: 'system'
    },
    {
        code: 'RECEPTION-001',
        status: 'active',
        maxUses: 5,
        usedCount: 1,
        expiresAt: '2025-12-31',
        role: 'receptionist',
        createdBy: 'system'
    },
    {
        code: 'TRAINER-001',
        status: 'active',
        maxUses: 5,
        usedCount: 0,
        expiresAt: '2025-12-31',
        role: 'trainer',
        createdBy: 'system'
    },
    {
        code: 'MANAGER-001',
        status: 'active',
        maxUses: 3,
        usedCount: 0,
        expiresAt: null, // Non-expiring admin code
        role: 'manager',
        createdBy: 'system'
    }
];

// Mock users - Pre-created staff accounts
let mockUsers = [
    {
        id: 1,
        username: 'manager1',
        password: 'manager123',
        name: 'John Manager',
        role: 'manager',
        invitationCode: 'MANAGER-2024',
        createdAt: '2024-01-01'
    },
    {
        id: 2,
        username: 'reception1',
        password: 'reception123',
        name: 'Sarah Receptionist',
        role: 'receptionist',
        invitationCode: 'RECEPTION-2024',
        createdAt: '2024-01-02'
    },
    {
        id: 3,
        username: 'trainer1',
        password: 'trainer123',
        name: 'Mike Trainer',
        role: 'trainer',
        invitationCode: 'TRAINER-2024',
        createdAt: '2024-01-03'
    }
];

let nextUserId = 4;

// Helper function to validate invitation
function validateInvitation(code) {
    const invitation = mockInvitations.find(inv => inv.code === code);
    
    if (!invitation) {
        return { valid: false, message: 'Invalid invitation code' };
    }
    
    if (invitation.status !== 'active') {
        return { valid: false, message: 'This invitation code is no longer active' };
    }
    
    // Check expiration only if expiresAt is set (null means non-expiring)
    if (invitation.expiresAt !== null) {
        const today = new Date();
        const expiryDate = new Date(invitation.expiresAt);
        if (expiryDate < today) {
            return { valid: false, message: 'This invitation code has expired' };
        }
    }
    
    if (invitation.usedCount >= invitation.maxUses) {
        return { valid: false, message: 'This invitation code has reached its usage limit' };
    }
    
    // Ensure invitation is for an allowed role
    if (!ALLOWED_ROLES.includes(invitation.role)) {
        return { valid: false, message: 'This invitation code is not valid for staff access' };
    }
    
    return { valid: true, invitation };
}

// POST /api/auth/validate-invitation - Validate invitation code
router.post('/validate-invitation', (req, res) => {
    try {
        const { invitationCode } = req.body;

        if (!invitationCode) {
            return res.status(400).json({
                success: false,
                message: 'Invitation code is required'
            });
        }

        const validation = validateInvitation(invitationCode);

        if (!validation.valid) {
            return res.status(400).json({
                success: false,
                message: validation.message
            });
        }

        res.status(200).json({
            success: true,
            message: 'Invitation code is valid',
            invitation: {
                code: validation.invitation.code,
                role: validation.invitation.role,
                remainingUses: validation.invitation.maxUses - validation.invitation.usedCount
            }
        });

    } catch (error) {
        console.error('Invitation validation error:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred while validating invitation code'
        });
    }
});

// POST /api/auth/login - Staff login with invitation code
router.post('/login', (req, res) => {
    try {
        const { username, password, invitationCode } = req.body;

        if (!username || !password) {
            return res.status(400).json({
                success: false,
                message: 'Username and password are required'
            });
        }

        if (!invitationCode) {
            return res.status(400).json({
                success: false,
                message: 'Invitation code is required'
            });
        }

        // Validate invitation code
        const validation = validateInvitation(invitationCode);
        if (!validation.valid) {
            return res.status(400).json({
                success: false,
                message: validation.message
            });
        }

        // Find user
        const user = mockUsers.find(u => u.username === username);

        if (!user || user.password !== password) {
            return res.status(401).json({
                success: false,
                message: 'Invalid username or password'
            });
        }

        // Check if user's invitation code matches
        if (user.invitationCode !== invitationCode) {
            return res.status(403).json({
                success: false,
                message: 'This invitation code is not associated with your account'
            });
        }

        // Verify user has an allowed role
        if (!ALLOWED_ROLES.includes(user.role)) {
            return res.status(403).json({
                success: false,
                message: 'Access denied. Only receptionists, trainers, and managers can access this system.'
            });
        }

        // Increment invitation usage
        validation.invitation.usedCount++;

        req.session.userId = user.id;
        req.session.username = user.username;
        req.session.userRole = user.role;
        req.session.isAuthenticated = true;

        res.status(200).json({
            success: true,
            message: 'Login successful',
            user: {
                id: user.id,
                username: user.username,
                name: user.name,
                role: user.role
            }
        });

    } catch (error) {
        console.error('Login error:', error);
        console.error('Error stack:', error.stack);
        res.status(500).json({
            success: false,
            message: 'An error occurred during login. Please try again later.',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// POST /api/auth/register - Register new staff member with invitation
router.post('/register', (req, res) => {
    try {
        const { username, password, name, invitationCode } = req.body;

        if (!username || !password || !invitationCode) {
            return res.status(400).json({
                success: false,
                message: 'Username, password, and invitation code are required'
            });
        }

        // Validate invitation code
        const validation = validateInvitation(invitationCode);
        if (!validation.valid) {
            return res.status(400).json({
                success: false,
                message: validation.message
            });
        }

        // Check if username already exists
        const existingUser = mockUsers.find(u => u.username === username);
        if (existingUser) {
            return res.status(409).json({
                success: false,
                message: 'Username already exists'
            });
        }

        // Create new user with role from invitation
        const newUser = {
            id: nextUserId++,
            username: username,
            password: password,
            name: name || username,
            role: validation.invitation.role, // Assign role from invitation
            invitationCode: invitationCode,
            createdAt: new Date().toISOString()
        };

        mockUsers.push(newUser);

        // Increment invitation usage
        validation.invitation.usedCount++;

        // Auto-login after registration
        req.session.userId = newUser.id;
        req.session.username = newUser.username;
        req.session.userRole = newUser.role;
        req.session.isAuthenticated = true;

        res.status(201).json({
            success: true,
            message: 'Registration successful',
            user: {
                id: newUser.id,
                username: newUser.username,
                name: newUser.name,
                role: newUser.role
            }
        });

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred during registration. Please try again later.'
        });
    }
});

// POST /api/auth/logout - Logout
router.post('/logout', (req, res) => {
    try {
        req.session.destroy((err) => {
            if (err) {
                console.error('Logout error:', err);
                return res.status(500).json({
                    success: false,
                    message: 'Error during logout'
                });
            }
            res.clearCookie('connect.sid');
            res.status(200).json({
                success: true,
                message: 'Logged out successfully'
            });
        });
    } catch (error) {
        console.error('Logout error:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred during logout'
        });
    }
});

// GET /api/auth/me - Get current user
router.get('/me', (req, res) => {
    try {
        if (!req.session.isAuthenticated || !req.session.userId) {
            return res.status(401).json({
                success: false,
                message: 'Not authenticated'
            });
        }

        const user = mockUsers.find(u => u.id === req.session.userId);

        if (!user) {
            req.session.destroy();
            return res.status(401).json({
                success: false,
                message: 'User not found'
            });
        }

        // Verify user has an allowed role
        if (!ALLOWED_ROLES.includes(user.role)) {
            req.session.destroy();
            return res.status(403).json({
                success: false,
                message: 'Access denied. Only receptionists, trainers, and managers can access this system.'
            });
        }

        res.status(200).json({
            success: true,
            user: {
                id: user.id,
                username: user.username,
                name: user.name,
                role: user.role
            }
        });

    } catch (error) {
        console.error('Get user error:', error);
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching user information'
        });
    }
});

// Authentication middleware
function requireAuth(req, res, next) {
    if (req.session && req.session.isAuthenticated) {
        // Verify user has an allowed role
        if (!ALLOWED_ROLES.includes(req.session.userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Access denied. Only receptionists, trainers, and managers can access this system.'
            });
        }
        next();
    } else {
        res.status(401).json({
            success: false,
            message: 'Authentication required'
        });
    }
}

// Role-based access control middleware
function requireRole(...allowedRoles) {
    return (req, res, next) => {
        if (!req.session || !req.session.isAuthenticated) {
            return res.status(401).json({
                success: false,
                message: 'Authentication required'
            });
        }

        const userRole = req.session.userRole;
        
        if (!allowedRoles.includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: `Access denied. This action requires one of the following roles: ${allowedRoles.join(', ')}`
            });
        }

        next();
    };
}

module.exports = router;
module.exports.requireAuth = requireAuth;
module.exports.requireRole = requireRole;
module.exports.ALLOWED_ROLES = ALLOWED_ROLES;