# Quick Start Guide - Body Fitness Center

## Prerequisites
- Node.js (v14+)
- MySQL Server (v5.7+)
- npm

## Setup Steps

### 1. Database Setup
```bash
# Connect to MySQL and run:
mysql -u root -p < Backend/setup.sql
```

Or manually:
```sql
CREATE DATABASE IF NOT EXISTS bfc_gym_db;
USE bfc_gym_db;
# Then run the SQL from Backend/setup.sql
```

### 2. Backend Setup
```bash
cd Backend
npm install
```

Create `.env` file:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=bfc_gym_db
DB_PORT=3306
PORT=3000
SESSION_SECRET=your-secret-key-change-in-production
FRONTEND_URL=http://localhost:5500
```

### 3. Start Backend Server
```bash
cd Backend
npm start
# or for development with auto-reload:
npm run dev
```

Server runs on `http://localhost:3000`

### 4. Start Frontend
```bash
cd frontend
# Option 1: Python
python -m http.server 5500

# Option 2: Node.js http-server
npx http-server -p 5500

# Option 3: VS Code Live Server (port 5500)
```

### 5. Access the System
Open browser: `http://localhost:5500/login.html`

**Default Login:**
- Username: `admin`
- Password: `admin123`

## Important Notes
- Backend must be running on port 3000
- Frontend must be running on port 5500
- CORS is configured for `http://localhost:5500`
- System uses session-based authentication (cookies)

## Troubleshooting
- **Login fails**: Check database connection and admin account exists
- **CORS errors**: Ensure frontend URL matches `FRONTEND_URL` in `.env`
- **Database errors**: Verify MySQL is running and credentials are correct
